#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/mman.h>
#include <termios.h>
#include <errno.h>
#include <string.h>
#include <sys/mman.h>
#include <sys/types.h>
#include <sys/stat.h>

#define  EXPORT		"/sys/class/gpio/export"
#define  DEV_NAME	"/dev/ttyS3" /* board uart */
#define pwm0 0
#define pwm1 1

int set_port( int fd, int nSpeed, int nBits, char nEvent, int nStop );

int main( int argc, char *argv[] )
{
    char    read_buf[4];
    char    write_buf[1];
    int    i, len, nread, r;
    int    uart_fd;
    int    ret;
    char command[100];
    /* char    buf[512]; */


    pwm_export(pwm0);
	pwm_enable(pwm0);
    pwm_polarity(pwm0,0);
    pwm_export(pwm1);
	pwm_enable(pwm1);
    pwm_polarity(pwm1,0);
    while ( 1 )
    {
    pwm_config(pwm0,20000000,500000);
    sleep(1);
    pwm_config(pwm0,20000000,1000000);
    sleep(1);
    pwm_config(pwm0,20000000,1500000);
    sleep(1);
    pwm_config(pwm0,20000000,2000000);
    sleep(1);
    pwm_config(pwm0,20000000,2500000);
    sleep(1);

    }
}

/***********GPIO***************/

// 导出 GPIO 引脚
void export_gpio(int gpio)
{
    char command[100];
    snprintf(command, sizeof(command), "echo %d > /sys/class/gpio/export", gpio);
    system(command);
}

// 设置 GPIO 引脚方向
void set_gpio_direction(int gpio, const char* direction)
{
    char command[100];
    snprintf(command, sizeof(command), "echo \"%s\" > /sys/class/gpio/gpio%d/direction", direction, gpio);
    system(command);
}

// 设置 GPIO 引脚值
void set_gpio_value(int gpio, int value)
{
    char command[100];
    snprintf(command, sizeof(command), "echo \"%d\" > /sys/class/gpio/gpio%d/value", value, gpio);
    system(command);
}

// GPIO 初始化
void gpio_init(int gpio, const char* direction, int value)
{
    export_gpio(gpio); // 导出 GPIO 引脚
    set_gpio_direction(gpio, direction); // 设置 GPIO 引脚方向
    set_gpio_value(gpio, value); // 设置 GPIO 引脚值
}

/*************PWM************/
//打开PWM接口
int pwm_export(unsigned int pwm)
{
    int fd;
	 if(pwm == 0)
	 {fd = open("/sys/class/pwm/pwmchip0/export",O_WRONLY);}
	 else if(pwm == 1)
	 {fd = open("/sys/class/pwm/pwmchip1/export",O_WRONLY);}
	 else if(pwm == 2)
	 {fd = open("/sys/class/pwm/pwmchip2/export",O_WRONLY);}
	 else if(pwm == 3)
	 {fd = open("/sys/class/pwm/pwmchip3/export",O_WRONLY);}

    if(fd<0)
    {
        printf("\nFailed expport PWM%c\n",pwm);
        return -1;
    }
    write(fd,"0",2);
    close(fd);
    return 0;
}

//关闭PWM接口
int pwm_unexport(unsigned int pwm)
{
    int fd;
	 if(pwm == 0)
	 {fd = open("/sys/class/pwm/pwmchip0/unexport",O_WRONLY);}
	 else if(pwm == 1)
	 {fd = open("/sys/class/pwm/pwmchip1/unexport",O_WRONLY);}
	 else if(pwm == 2)
	 {fd = open("/sys/class/pwm/pwmchip2/unexport",O_WRONLY);}
	 else if(pwm == 3)
	 {fd = open("/sys/class/pwm/pwmchip3/unexport",O_WRONLY);}
    if(fd<0)
    {
        printf("\nFailed unexpport PWM%d\n",pwm);
        return -1;
    }
    write(fd,"0",2);
    close(fd);
    return 0;
}
//使能pwm
int pwm_enable(unsigned int pwm)
{
    int fd;
    if(pwm == 0)
	 {fd = open("/sys/class/pwm/pwmchip0/pwm0/enable",O_WRONLY);}
	 else if(pwm == 1)
	 {fd = open("/sys/class/pwm/pwmchip1/pwm0/enable",O_WRONLY);}
	 else if(pwm == 2)
	 {fd = open("/sys/class/pwm/pwmchip2/pwm0/enable",O_WRONLY);}
	 else if(pwm == 3)
	 {fd = open("/sys/class/pwm/pwmchip3/pwm0/enable",O_WRONLY);}
    if(fd<0)
    {
        printf("\nFailed enable PWM%d\n",pwm);
        return -1;
    }
    write(fd,"1",2);
    close(fd);
    return 0;
}
//禁止使能pwm
int pwm_disable(unsigned int pwm)
{
    int fd;
    if(pwm == 0)
	 {fd = open("/sys/class/pwm/pwmchip0/pwm0/enable",O_WRONLY);}
	 else if(pwm == 1)
	 {fd = open("/sys/class/pwm/pwmchip1/pwm0/enable",O_WRONLY);}
	 else if(pwm == 2)
	 {fd = open("/sys/class/pwm/pwmchip2/pwm0/enable",O_WRONLY);}
	 else if(pwm == 3)
	 {fd = open("/sys/class/pwm/pwmchip3/pwm0/enable",O_WRONLY);}
    if(fd<0)
    {
        printf("\nFailed disable PWM%d\n",pwm);
        return -1;
    }
    write(fd,"0",2);
    close(fd);
    return 0;
}

//设置占空比
int pwm_config(unsigned int pwm,unsigned int period,unsigned int duty_cycle)
{
    int fd,len_p,len_d;
    char buf_p[10];
    char buf_d[10];
    
    len_p = snprintf(buf_p,sizeof(buf_p),"%d",period);
    len_d = snprintf(buf_d,sizeof(buf_d),"%d",duty_cycle);
    
    if(pwm == 0)
	 {fd = open("/sys/class/pwm/pwmchip0/pwm0/period",O_WRONLY);}
	 else if(pwm == 1)
	 {fd = open("/sys/class/pwm/pwmchip1/pwm0/period",O_WRONLY);}
	 else if(pwm == 2)
	 {fd = open("/sys/class/pwm/pwmchip2/pwm0/period",O_WRONLY);}
	 else if(pwm == 3)
	 {fd = open("/sys/class/pwm/pwmchip3/pwm0/period",O_WRONLY);}
    if(fd<0)
    {
        printf("\nFailed set PWM period%d\n",pwm);
        return -1;
    }
    write(fd,buf_p,len_p);
	close(fd);

    if(pwm == 0)
	 {fd = open("/sys/class/pwm/pwmchip0/pwm0/duty_cycle",O_WRONLY);}
	 else if(pwm == 1)
	 {fd = open("/sys/class/pwm/pwmchip1/pwm0/duty_cycle",O_WRONLY);}
	 else if(pwm == 2)
	 {fd = open("/sys/class/pwm/pwmchip2/pwm0/duty_cycle",O_WRONLY);}
	 else if(pwm == 3)
	 {fd = open("/sys/class/pwm/pwmchip3/pwm0/duty_cycle",O_WRONLY);}
    if(fd<0)
    {
        printf("\nFailed set PWM duty_cycle%d\n",pwm);
        return -1;
    }
    write(fd,buf_d,len_d);
    close(fd);
    return 0;
}

//设置极性
int pwm_polarity(int pwm,int polarity)
{
    int fd;
    if(pwm == 0)
	 {fd = open("/sys/class/pwm/pwmchip0/pwm0/polarity",O_WRONLY);}
	 else if(pwm == 1)
	 {fd = open("/sys/class/pwm/pwmchip1/pwm0/polarity",O_WRONLY);}
	 else if(pwm == 2)
	 {fd = open("/sys/class/pwm/pwmchip2/pwm0/polarity",O_WRONLY);}
	 else if(pwm == 3)
	 {fd = open("/sys/class/pwm/pwmchip3/pwm0/polarity",O_WRONLY);}
    
    if(fd<0)
    {
        printf("\nFailed set PWM polarity%d\n",pwm);
        return -1;
    }
    if(polarity==1)
    {
        write(fd,"normal",6);
    }
    else if(polarity==0)
    {
        write(fd,"inversed",8);
    }
    close(fd);
    return 0;
}


/**************UART********************/
int Uart_Send( int fd, char *send_buf, int data_len )
{
	int ret;

	ret = write( fd, send_buf, data_len );

	if ( data_len == ret )
	{
		return(ret);
	} else{
		return(0);
	}
}

/*
函数 `set_port` 用于配置串行端口的参数。这个函数的参数分别代表串口通信的不同属性：
- `fd`: 文件描述符，用于指定要配置的串行端口 用open_port返回。
- `nSpeed`: 波特率，指定串行通信的速率，例如 9600、19200、115200 等。
- `nBits`: 数据位，指定每个字符包含的数据位数，通常为 7 或 8 位。
- `nEvent`: 校验位，指定是否使用奇校验('O')、偶校验('E')或不使用校验('N')。
- `nStop`: 停止位，指定每个字符后面的停止位数，通常为 1 或 2 位。
例如，如果你调用 `set_port(fd, 9600, 8, 'N', 1)`，那么你就是在配置串口以 9600 波特率、8 数据位、无校验位和 1 停止位的设置进行通信。

*/
int set_port( int fd, int nSpeed, int nBits, char nEvent, int nStop )
{
	struct termios newtio, oldtio;

	memset( &oldtio, 0, sizeof(oldtio) );
	/* save the old serial port configuration */
	if ( tcgetattr( fd, &oldtio ) != 0 )
	{
		perror( "set_port/tcgetattr" );
		return(-1);
	}

	memset( &newtio, 0, sizeof(newtio) );
	/* ignore modem control lines and enable receiver */
	newtio.c_cflag	= newtio.c_cflag |= CLOCAL | CREAD;
	newtio.c_cflag	&= ~CSIZE;
	/* set character size */
	switch ( nBits )
	{
	case 8:
		newtio.c_cflag |= CS8;
		break;
	case 7:
		newtio.c_cflag |= CS7;
		break;
	case 6:
		newtio.c_cflag |= CS6;
		break;
	case 5:
		newtio.c_cflag |= CS5;
		break;
	default:
		newtio.c_cflag |= CS8;
		break;
	}
	/* set the parity */
	switch ( nEvent )
	{
	case 'o':
	case 'O':
		newtio.c_cflag	|= PARENB;
		newtio.c_cflag	|= PARODD;
		newtio.c_iflag	|= (INPCK | ISTRIP);
		break;
	case 'e':
	case 'E':
		newtio.c_cflag	|= PARENB;
		newtio.c_cflag	&= ~PARODD;
		newtio.c_iflag	|= (INPCK | ISTRIP);
		break;
	case 'n':
	case 'N':
		newtio.c_cflag &= ~PARENB;
		break;
	default:
		newtio.c_cflag &= ~PARENB;
		break;
	}
	/* set the stop bits */
	switch ( nStop )
	{
	case 1:
		newtio.c_cflag &= ~CSTOPB;
		break;
	case 2:
		newtio.c_cflag |= CSTOPB;
		break;
	default:
		newtio.c_cflag &= ~CSTOPB;
		break;
	}
	/* set output and input baud rate */
	switch ( nSpeed )
	{
	case 0:
		cfsetospeed( &newtio, B0 );
		cfsetispeed( &newtio, B0 );
		break;
	case 50:
		cfsetospeed( &newtio, B50 );
		cfsetispeed( &newtio, B50 );
		break;
	case 75:
		cfsetospeed( &newtio, B75 );
		cfsetispeed( &newtio, B75 );
		break;
	case 110:
		cfsetospeed( &newtio, B110 );
		cfsetispeed( &newtio, B110 );
		break;
	case 134:
		cfsetospeed( &newtio, B134 );
		cfsetispeed( &newtio, B134 );
		break;
	case 150:
		cfsetospeed( &newtio, B150 );
		cfsetispeed( &newtio, B150 );
		break;
	case 200:
		cfsetospeed( &newtio, B200 );
		cfsetispeed( &newtio, B200 );
		break;
	case 300:
		cfsetospeed( &newtio, B300 );
		cfsetispeed( &newtio, B300 );
		break;
	case 600:
		cfsetospeed( &newtio, B600 );
		cfsetispeed( &newtio, B600 );
		break;
	case 1200:
		cfsetospeed( &newtio, B1200 );
		cfsetispeed( &newtio, B1200 );
		break;
	case 1800:
		cfsetospeed( &newtio, B1800 );
		cfsetispeed( &newtio, B1800 );
		break;
	case 2400:
		cfsetospeed( &newtio, B2400 );
		cfsetispeed( &newtio, B2400 );
		break;
	case 4800:
		cfsetospeed( &newtio, B4800 );
		cfsetispeed( &newtio, B4800 );
		break;
	case 9600:
		cfsetospeed( &newtio, B9600 );
		cfsetispeed( &newtio, B9600 );
		break;
	case 19200:
		cfsetospeed( &newtio, B19200 );
		cfsetispeed( &newtio, B19200 );
		break;
	case 38400:
		cfsetospeed( &newtio, B38400 );
		cfsetispeed( &newtio, B38400 );
		break;
	case 57600:
		cfsetospeed( &newtio, B57600 );
		cfsetispeed( &newtio, B57600 );
		break;
	case 115200:
		cfsetospeed( &newtio, B115200 );
		cfsetispeed( &newtio, B115200 );
		break;
	case 230400:
		cfsetospeed( &newtio, B230400 );
		cfsetispeed( &newtio, B230400 );
		break;
	default:
		cfsetospeed( &newtio, B115200 );
		cfsetispeed( &newtio, B115200 );
		break;
	}
	/* set timeout in deciseconds for non-canonical read */
	newtio.c_cc[VTIME] = 0;
	/* set minimum number of characters for non-canonical read */
	newtio.c_cc[VMIN] = 0;
	/* flushes data received but not read */
	tcflush( fd, TCIFLUSH );


	/* set the parameters associated with the terminal from
	 * the termios structure and the change occurs immediately */
	if ( (tcsetattr( fd, TCSANOW, &newtio ) ) != 0 )
	{
		perror( "set_port/tcsetattr" );
		return(-1);
	}

	return(0);
}


/**
 * @brief: open serial port
 * @Param: dir: serial device path
 */
int open_port( char *dir )
{
	int fd;
	fd = open( dir, O_RDWR );
	if ( fd < 0 )
	{
		perror( "open_port" );
	}
	return(fd);
}

