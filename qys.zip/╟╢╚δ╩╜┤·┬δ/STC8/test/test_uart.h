#ifndef __TEST_UART_H
#define __TEST_UART_H



/**
  * @brief    ���Դ���   
  *
  * @param    ��
  *
  * @return   ��
  *
  * @note     
  *
  * @example  
  *
*/
void Test_UART();

#endif