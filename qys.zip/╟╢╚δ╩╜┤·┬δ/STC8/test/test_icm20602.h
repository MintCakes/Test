#ifndef __TEST_ICM20602_H
#define __TEST_ICM20602_H



/**
  * @brief    ��ȡICM20602ԭʼ���� ����
  *
  * @param    
  *
  * @return   
  *
  * @note     
  *
  * @example  
  *
  */
void Test_ICM20602();

#endif