#include "test_key.h"
#include "yl_key.h"
#include "yl_led.h"


/** �����ⲿ��ʱ���� */
extern void delayms(uint32_t ms);


/**
  * @brief    ���԰���
  *
  * @param    ��
  *
  * @return   ��
  *
  * @note     ��
  *
  * @see      Test_KEY();
  *
  * @date     2019/6/4 ���ڶ�
  */
void Test_KEY(void)
{ 
    LED_Init();
    KEY_Init(); 
    while (1)
    {  
        switch(KEY_Read(1))  
        {
            case 1:
                LED_Color(red);     
                break;           
            case 2:      
                LED_Color(green);   
                break;
            case 3:      
                LED_Color(blue);    
                break;
            default:
                LED_Color(white);   
                break;
        }

        delayms(50);
    }
}