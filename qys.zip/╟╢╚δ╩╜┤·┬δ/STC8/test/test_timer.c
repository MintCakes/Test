#include "test_timer.h"
#include "yl_timer.h"
#include "yl_led.h"



/**
  * @brief    ���Զ�ʱ���ж�   
  *
  * @param    ��
  *
  * @return   ��
  *
  * @note     
  *
  * @example  
  *
  * @date     2020/4/1 
*/
void Test_TIMER()
{
	uint32_t xdata msysTick = 0;
	uint32_t xdata msysTime = 0;
	TIMER0_InitSys();
	LED_Init();
	
	while(1)
	{
		/* �ж� 500 ms �Ƿ��ȥ */
		msysTime = TIMER0_GetUs() - msysTick;
		if(msysTime > 500000UL)
		{
			msysTick = TIMER0_GetUs();
			
			LED_ColorReverse(red);
		}
	}
	
}
