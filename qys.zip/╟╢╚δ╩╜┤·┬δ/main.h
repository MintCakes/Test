#ifndef __YL_MAIN_H
#define __YL_MAIN_H

typedef 	unsigned char	u8;


/* 51 �ײ�ͷ�ļ� */
#include "stc8.h"
#include "intrins.h"
#include "stdio.h"
#include "yl_adc.h"
#include "yl_enc.h"
#include "yl_gpio.h"
#include "yl_pwm.h"
#include "yl_spi.h"
#include "yl_timer.h"
#include "yl_uart.h"
#include "yl_softiic.h"
#include "yl_eeprom.h"

/* ģ������ͷ�ļ� */
#include "yl_led.h"
#include "yl_key.h"
#include "yl_oled.h"
#include "yl_mpu6050.h"
#include "yl_icm20602.h"
#include "yl_9ax.h"
#include "ANO_DT.h"


void delayms(uint32_t ms);  //��ʱ����
void dianci(void);

#endif
