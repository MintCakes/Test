#include <STC8.H>
#include "main.h"
/* 测试函数头文件 */
#include "test_adc.h"
#include "test_enc.h"
#include "test_exti.h"
#include "test_timer.h"
#include "test_uart.h"
#include "test_eeprom.h"
#include "test_mpu6050.h"
#include "test_icm20602.h"
#include "test_9ax.h"
#include "test_ano_dt.h"
#include "test_key.h"
#include "test_led.h"
#include "test_oled.h"
#include "test_pwm.h"
#include "test_ccd.h"
#include "test_lsm6dsr.h"

void delayms(uint32_t ms)  //延时函数
{
	while(ms--)
	{
		uint16_t xdata i = 300;
		while(i--)
		{
			NOP(50);
		}
	}
}
#define Servo_Delta 100            //舵机左右转动的差值，与舵机型号，拉杆和舵机臂长有关
#define Servo_Left_Max   (Servo_Center_Mid+Servo_Delta)      //舵机左转极限值
#define Servo_Right_Min  (Servo_Center_Mid-Servo_Delta)      //舵机右转极限值，此值跟舵机放置方式有关，立式

unsigned int Hour=0,Min=0,Sec=0,count=0,flag=0,Sec1=0,RAll=0;
unsigned int huoyan=0,hongwai=0;

unsigned int  diangan[4];
short leftP=0,leftV=0,rightV=0,rightP=0;  //70 60 60 70
short TempAngle_P = 0,Last_TempAngle_P=0;   // 水平电感偏差
short TempAngle_V = 0,Last_TempAngle_V=0;		// 垂直电感偏差
short Error_P=0,Error_V=0;
short MotorDuty1=0; 				// 定义左电机全局变量
short MotorDuty2=0;				// 定义右电机全局变量
int xdata ECPULSE1 = 0;         		// 定义左编码器全局变量
int xdata ECPULSE2 = 0;          		// 定义右编码器全局变量

int RAllPulse1=0;
int RAllPulse2=0;

float DJ_KP1=-0.5,DJ_KD1=0.0,DJ_V1 = 0.00;//直道
float DJ_KP2=-0.6,DJ_KD2=0.0,DJ_V2 = 0.00;//小弯
short ServoDuty=0,Last_ServoDuty=0;	//舵机增量

short Err_speed = 0;				//转弯差速

short S_curve=0,Straight=0,Stop=0; // 小弯 大弯 直路 停车
short devi_fig=0;		//状态标志位
short time = 0;	



short key_flag= 0;
short zhi_wan = 0;		
short xiao_da = 1;
short motor_flag = 1;
short jiemian = 0;

//圆环PID
//short DJ_KP4=1.8,DJ_KD4=0.0;
short DJ_KP5=2.0,DJ_KD5=0.0;
short DJ_KP6=2.0,DJ_KD6=0.0;
short DJ_KP7=1.5,DJ_KD7=0.0;
short Round=0,Round_In=0,Rounding=0,Round_Out=0,Round_Oflag=0; // 圆环标志位
short infrared =0;  //光电传感器标志位
short obs_flag=0,obs_In=0,obs_ing=0,obs_Out=0;  // 障碍标志位

// 出库入库
short Gar_Out=0,Gar_In=0;

void InductorNormal (void);
void Discern(void);
void steering_control(void);
void OLED_show(void);
void MotorCtrl (int16_t duty1,int16_t duty2);
void Key_Scan(void);
void main()
{
	char txt[36] = {0};
	RSTCFG = 0x50; //复位寄存器，默认P54用作复位引脚
	EA = 1;                //开启总中断

	
	LED_Init();  
	KEY_Init(); 
	OLED_Init();                          //LCD初始化 
  delayms(500);  
  OLED_CLS();   
	ADC8_Init() ;              // 电感初始化 P00
	ADC9_Init() ;							 // 电感初始化 P01
	ADC10_Init();							 // 电感初始化 P02
	ADC11_Init();							 // 电感初始化 P03
	PWM_Init(0, 0, 12500, 0);  // 电机初始化 P10
	PWM_Init(1, 1, 12500, 0);  // 电机初始化 P22
	PWM_Init(1, 2, 12500, 0);  // 电机初始化 P24
	PWM_Init(1, 3, 12500, 0);  // 电机初始化 P26
	PWM_Init(0, 7, 50, Servo_Center_Mid);   // 舵机初始化 P10
	TIMER3_EncInit();   //初始化定时器3  对P04管脚 脉冲计数
	TIMER4_EncInit();   //初始化定时器4  对P06管脚 脉冲计数
	PIN_InitStandard(0, 5);	// 初始化 编码器方向管脚
	PIN_InitStandard(4, 7);	// 初始化 编码器方向管脚
	PIN_InitStandard(1, 1);	// 初始化 光电管方向管脚
	PIN_InitStandard(3, 7);	// 初始化 干簧管方向管脚
//	PIN_InitPushPull(1, 6); // 蜂鸣器初始化
	TIMER0_Init(5000);
	TIMER1_Init(5000);	//定时器1  5ms中断
UART3_InitTimer2P50P51(115200);  
TR1=0;

	while(1)
	{
		P35=1;
		P33=1;
		Key_Scan();		//按键扫描
		OLED_show();
    PWM_SetDuty(0, 7, Servo_Center_Mid+ServoDuty );

		if(Hour==0&&Min==0&&Sec==5)
		{
		  TR1=1;
		}
		if(RAllPulse1>10000)
		{
		  RAllPulse1=0;
			RAll++;
		}
		if(RAll>2&&flag==0)
		{
		  Sec1=Sec;
			while(Sec<(Sec1+5))
			{
				if(P35==0) 
		{
			printf('1');
			huoyan=1; 
			PIN_InitPushPull(1, 6); // 蜂鸣器初始化
		}
		if(P33==0)
		{
			printf('1');
			hongwai=2;
			PIN_InitPushPull(1, 6); // 蜂鸣器初始化
		}
			
      PWM_SetDuty(0, 0, 0);
			PWM_SetDuty(1, 1, 0);
			PWM_SetDuty(1, 2, 0);
			PWM_SetDuty(1, 3, 0);
			}
			huoyan=0;
			hongwai=0;
			PIN_InitPureInput(1,6);
			flag=1;
		}
		if(RAll>5&&flag==1)
		{
		  Sec1=Sec;
			while(Sec<(Sec1+5))
			{
				
			if(P35==0)
		{
			printf('1');
			huoyan=1;
			PIN_InitPushPull(1, 6); // 蜂鸣器初始化
		}
		if(P33==0)
		{
			printf('1');
			hongwai=2;
			PIN_InitPushPull(1, 6); // 蜂鸣器初始化
		}
      PWM_SetDuty(0, 0, 0);
			PWM_SetDuty(1, 1, 0);
			PWM_SetDuty(1, 2, 0);
			PWM_SetDuty(1, 3, 0);
			}
			huoyan=0;
			hongwai=0;
			PIN_InitPureInput(1,6);
			flag=2;
		} 
		if(RAll>11&&flag==2)
		{
			while(Min<2&&zhi_wan==0)
			{
//				Key_Scan();		//按键扫描
			LED_Color(blue);
      PWM_SetDuty(0, 0, 0);   
			PWM_SetDuty(1, 1, 0);    
			PWM_SetDuty(1, 2, 0);
			PWM_SetDuty(1, 3, 0);
			}
			flag=0;
			RAll=0;
			zhi_wan==1;
		}
	

	}
}
//该函数5ms运行一次，在定时器中断里面调用
void dianci(void)
{
	
	TIMER3_GetValue(ECPULSE2);		//编码器速度采集
	if(!P05)
	{
		ECPULSE2 = -ECPULSE2;				//编码器结果正负判断
	}
	TIMER4_GetValue(ECPULSE1);		//编码器速度采集
	if(P47)
	{
		ECPULSE1 = -ECPULSE1;				//编码器结果正负判断
	}
	RAllPulse1+=ECPULSE1;				// 编码器采集值累加
	RAllPulse2+=ECPULSE2;				// 编码器采集值累加
	InductorNormal();					  //电感采集和归一化

		Discern();									// 元素识别
		steering_control();					//元素处理和pid运算
	
	PWM_SetDuty(0, 7, Servo_Center_Mid+ServoDuty );		//舵机控制
	MotorCtrl(MotorDuty1,MotorDuty2);	//电机控制
}

//////元素识别///////
void Discern(void)
{

		if(leftV<3&&rightV<3) // 接近冲出赛道停车
			{
				Round = 0;							
				Straight=0;  
				S_curve=0;		
				Stop = 1;	
			}
			

				 else if((leftV>7)&&(rightV>7)) //直道循迹
				{
						Round = 0;
						Straight=1;
						S_curve=0;
						Stop = 0;
				}
				else  // 弯道循迹
				{
						Round = 0;							
						Straight=0;  
						S_curve=1;		
						Stop = 0;	
				}
				if(RAllPulse1==-30000)
				{
				  devi_fig = 3;
					EA=0;
				}

	
	if(Straight == 1)
		devi_fig=0;
	else if(S_curve == 1)
		devi_fig=1;
	else if(Stop == 1)
		devi_fig = 3;
	else if(Round_In==1)
		devi_fig = 4;
	else if(Rounding==1)
		devi_fig = 5;
	else if(Round_Out==1)
		devi_fig = 6;
	else if(Round_Oflag == 1)
		devi_fig = 7;
	else if(obs_In==1)
		devi_fig = 9;
	else if(obs_ing==1)
		devi_fig = 10;
	else if(obs_Out==1)
		devi_fig = 11;
}

//////// 舵机电机控制/////////////
void steering_control(void)      
{
	
	//舵机控制
	switch(devi_fig)
	{
		case 0: ServoDuty=(int)(TempAngle_V*DJ_KP1+Error_V*DJ_KD1);
						//Err_speed=(short)(Ser voDuty*DJ_V1+0.5);
						break;  // 直道PID 差速
		case 1:	ServoDuty=(int)(TempAngle_V*DJ_KP2+Error_V*DJ_KD2);
						//Err_speed=(short)(ServoDuty*DJ_V2+0.5); 
						break;	 //	小弯PID 差速
		case 3:	ServoDuty=0;break;	// 冲出记忆
		case 4:	ServoDuty=80;break;   // 进圆环PID
		case 5:	ServoDuty=(int)(TempAngle_V*DJ_KP5);break;   // 圆环中PID
		case 6:	ServoDuty=(int)(TempAngle_V*DJ_KP6);break;   // 出圆环PID 
		case 7:	ServoDuty=-30;break;	
		case 8:	ServoDuty=30;break;
		// 障碍
		case 9:	ServoDuty=100;break;	
		case 10:	ServoDuty=-30;break;
		case 11:	ServoDuty=-100;break;

	}
	if(ServoDuty> Servo_Delta) ServoDuty=  Servo_Delta;
	if(ServoDuty<-Servo_Delta) ServoDuty= -Servo_Delta;
	
	
	// 电机控制
	if(Stop == 1)	//冲出赛道 停车
		MotorDuty1 = MotorDuty2 = 0;	

	else
	{
		MotorDuty1 = -2000;
		MotorDuty2 = -2000;
	}
	if(motor_flag == 0)
	{
		MotorDuty1 = MotorDuty2=0;
	} 
	
	
	
	
}
/////////按键扫描函数////////////
void Key_Scan(void)
{
	char key_value = 0;
	key_value = KEY_Read(1);
	if(key_value == 1)
	{
		if(jiemian == 0)
			jiemian = 1;
		else if(jiemian == 1)
			jiemian = 2;
		else if(jiemian == 2)
			jiemian = 0;
	}
	else if(key_value == 2)
	{
		if(jiemian == 0)
			DJ_KD1 += 0.1;
		else if(jiemian == 1)
			DJ_KD2 += 0.1;
		else if(jiemian == 2)
			zhi_wan += 1;
	}
	else if(key_value == 3)
	{
		if(jiemian == 0)
			DJ_KD1 -= 0.1;
		else if(jiemian == 1)
			DJ_KD2 -= 0.1;
		else if(jiemian == 2)
			zhi_wan -= 1;
	}
	delayms(100);
} 

//////////// 屏幕显示/////////////////
void OLED_show(void)
{
	char txt[30];
	sprintf(txt,"%4d %4d %4d    ",Hour,Min,Sec);// 电感原始值
	OLED_P6x8Str(0,0,(u8*)txt);
	sprintf(txt,"L:%03d %03d %03d %03d",leftV,leftP,rightP,rightV);		// 水平电感
	OLED_P6x8Str(0,1,(u8*)txt);
	sprintf(txt,"T:%04d %04d",TempAngle_V,TempAngle_P);	// 水平偏差和垂直偏差
	OLED_P6x8Str(0,2,(u8*)txt);
	sprintf(txt,"PWM:%04d %04d ",MotorDuty1,MotorDuty2);	// 电机PWM值
	OLED_P6x8Str(0,3,(u8*)txt);
	sprintf(txt,"flag:%3d  %3d %d ",ECPULSE1,ECPULSE2,devi_fig);
	OLED_P6x8Str(0,4,(u8*)txt);
	sprintf(txt,"P1:%1.1f  %1.3f  %d   ",DJ_KD1,DJ_KP1,jiemian);
	OLED_P6x8Str(0,5,(u8*)txt);
	sprintf(txt,"P2:%1.1f  %1.3f   %d  ",DJ_KD2,DJ_KP2,zhi_wan);
	OLED_P6x8Str(0,6,(u8*)txt);
	sprintf(txt,"RE:%05d %05d",RAll,RAllPulse2);
	OLED_P6x8Str(0,7,(u8*)txt);	
}

void InductorNormal (void)
{
		ADC_GetValue(8,diangan[0]);    	// 读取ADC8通道值  P00
		ADC_GetValue(9,diangan[1]);			// 读取ADC9通道值	 P01
		ADC_GetValue(10,diangan[2]); 		// 读取ADC10通道值 P02
		ADC_GetValue(11,diangan[3]);		// 读取ADC11通道值 P03
		
		leftV =  (float)(diangan[0] - 100.0) / (1800.0 - 100.0) * 100.0;		// 电感归一化
		leftP =  (float)(diangan[1] - 100.0) / (1800.0 - 100.0) * 100.0;		// 电感归一化
		rightP = (float)(diangan[2] - 100.0) / (1800.0 - 100.0) * 100.0;		// 电感归一化
		rightV = (float)(diangan[3] - 100.0) / (1800.0 - 100.0) * 100.0;		// 电感归一化			

		leftP = (leftP < 0) ? 0 : leftP;            //归一化后限制输出幅度
		leftP = (leftP > 100) ? 100 : leftP;			  //归一化后限制输出幅度
		rightV = (rightV < 0) ? 0 : rightV;				  //归一化后限制输出幅度
		rightV = (rightV > 100) ? 100 : rightV;			//归一化后限制输出幅度
		leftV = (leftV < 0) ? 0 : leftV;				    //归一化后限制输出幅度
		leftV = (leftV > 100) ? 100 : leftV;			  //归一化后限制输出幅度
		rightP = (rightP < 0) ? 0 : rightP;				  //归一化后限制输出幅度
		rightP = (rightP > 100) ? 100 : rightP;			//归一化后限制输出幅度	
	
		TempAngle_V=(leftV-rightV)*100/(leftV+rightV);	// 差比和计算水平偏差,
		Error_V = TempAngle_V-Last_TempAngle_V;					// 水平偏差微分
		Last_TempAngle_V = TempAngle_V;								  // 记忆水平偏差
		
		TempAngle_P=(leftP-rightP)*100/(leftP+rightP);	// 垂直偏差
		Error_P = TempAngle_P-Last_TempAngle_P;					// 垂直偏差微分
		Last_TempAngle_P = TempAngle_P;									// 记忆垂直偏差
}

// 电机控制函数，BTN7971后轮双PWM控制
void MotorCtrl (int16_t duty1,int16_t duty2)
{
	
	if(duty1 >= 0)
	{
		PWM_SetDuty(0, 0, duty1); 		// P 1.0
		PWM_SetDuty(1, 1, 0);					// P 2.2
	}
	else
	{
		PWM_SetDuty(0, 0, 0);					// P 1.0
		PWM_SetDuty(1, 1, 0-duty1);		// P 2.2
	}
	if(duty2 >= 0){
		PWM_SetDuty(1, 2, duty2); 		// P 2.4
		PWM_SetDuty(1, 3, 0); 				// P 2.6
	}
	else{
		PWM_SetDuty(1, 2, 0);					// P 2.4
		PWM_SetDuty(1, 3, 0-duty2); 	// P 2.6
	}
}

